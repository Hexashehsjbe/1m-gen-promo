# Opera GX Promo Generator

This tool generates 1 month promo links using the Opera X Discord promotion.

Don't ask me for help on how to use it.